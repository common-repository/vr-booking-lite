//jQuery.datetimepicker.setLocale('en');

jQuery(function(){
jQuery( "#booking" ).validate({
  rules: {
    first_name: {
      required: true
    },
    last_name: {
      required: true
    },
    email: {
      required: true,
      email: true
    },
    tel1: {
      required: true
    }
  }
});

jQuery( "#get_quote" ).validate({
  rules: {
    location: {
      required: true
    },
    date_from: {
      required: true
    },
    date_to: {
      required: true
    },
    adults: {
      required: true
    }
  }
});
});

jQuery('#date_from').datetimepicker({
  format:'d/m/Y',
  timepicker:false,
  scrollInput:false,
  minDate: 0,
  lang:'en',
  onSelectDate:function(ct,$i){
    var d = jQuery('#date_from').datetimepicker('getValue');
    d.setTime(d.getTime() + 86400000);
    var next_day_year = d.getFullYear();
    var next_day_month = d.getMonth()+1;
    next_day_month = (parseInt(next_day_month)<10)?"0"+next_day_month:next_day_month;
    var next_day_day = d.getDate();
    next_day_day = (parseInt(next_day_day)<10)?"0"+next_day_day:next_day_day;
    //alert(d);
    //$('#booking_date_in').val(d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear());
    jQuery('#date_to').datetimepicker('setOptions', {minDate: d});
    jQuery('#date_to').val(next_day_day + "/" + next_day_month + "/" + next_day_year);
  },
}).on('focus',function()
    {
        jQuery(this).blur();
    });

jQuery('#date_to').datetimepicker({
  format:'d/m/Y',
  timepicker:false,
  scrollInput:false,
  minDate: '+1970/01/02',
  lang:'en',
}).on('focus',function()
    {
        jQuery(this).blur();
    });

jQuery(function($){
            $('#modify').click(function(){
    		$('#search-form').toggleClass('active');
         });
});

function success_contact_popup(){
   jQuery('#overlay').fadeIn(400, function(){
				jQuery('#success_contact')
					.css('display', 'block')
					.animate({opacity: 1}, 200);
		    });
}

jQuery(function($){
      $('#tab_block .doc_tab').click(function () {
        $('#tab_block .doc_tab.cur_tab').removeClass('cur_tab');
        $(this).addClass('cur_tab');
        var div_tab = $(this).attr('data-x');
        $('#app-page .doc_tab_div.active').removeClass('active');
        $('#'+div_tab).addClass('active');
});
});
//////////////////////////////////////

jQuery(function($){
      $('.search-result .pager_num').on('click' , function () {
      var page_num = $(this).attr('data-x');
      var page_num_add = '/page_num/'+page_num;
      var form = $('<form id="new_form_search" action="/search-result' +page_num_add + '" method="post"><input type="hidden" name="date_from" value="'+$('#date_from').val()+'"><input type="hidden" name="date_to" value="'+$('#date_to').val()+'"><input type="hidden" name="adults" value="'+$('#adults').val()+'"><input type="hidden" name="bedrooms" value="'+$('#bedrooms').val()+'"></form>');
      $('body').append(form);
      form.submit();
});
});

//////////////////////////////////////
