<?php

//      General functions

if ( ! defined( 'ABSPATH' ) )
	exit;

// Add support for Post Thumbnails.
add_theme_support( 'post-thumbnails' );
//set_post_thumbnail_size( 200, 150, true ); // Normal post thumbnails
add_image_size( 'post1-thumbnail', 320, 200, true );

///////////////////////////

add_filter( 'body_class', function( $classes ) {
    $pref = explode("/", $_SERVER['REQUEST_URI']);
    if ($pref[1] == 'search-result')
    return array_merge( $classes, array( 'search-result' ) );
    elseif ($pref[1] == 'thank-you')
    return array_merge( $classes, array( 'thank-you' ) );
    else
    return $classes;
} );

/////////////////////////////

add_filter( 'ajax_query_attachments_args', 'vrb_show_current_post_attachments', 10, 1 );
function vrb_show_current_post_attachments( $query = array() ) {
    add_filter( 'posts_where', 'vrb_wpse_add_posts_where', 10, 2 );
    return $query;
}

function vrb_wpse_add_posts_where( $where, $query ) {
    global $wpdb;
    $post_id = intval($_POST['post_id']);
    $where .= $wpdb->prepare( ' AND (' . $wpdb->posts . '.post_parent = %s )', $post_id );
    return $where;
}

//Manage Your Media Only
function vrb_mymo_parse_query_unattach( $wp_query ) {
    if ( strpos( $_SERVER[ 'REQUEST_URI' ], '/wp-admin/upload.php' ) !== false ) {
            $wp_query->set( 'post_parent', 0 );
    }
}
add_filter('parse_query', 'vrb_mymo_parse_query_unattach' );

/***Tuning****/

add_action( 'do_meta_boxes', 'vrb_remove_plugin_metaboxes' );
function vrb_remove_plugin_metaboxes(){
        remove_meta_box( 'slugdiv', 'property', 'normal' );
}

//////// CMB2 general functions  ////////////////////////

function vrb_cmb2_get_property_options() {
    $args = array(
        'post_type'   => 'property',
        'numberposts' => -1,
    );
    $posts = get_posts( $args );
    $post_options = array();
    if ( $posts ) {
        foreach ( $posts as $post ) {
          $post_options[ $post->ID ] = $post->post_title;
        }
    }
    return $post_options;
}

/////////// admin columns  ////////////////

add_filter('manage_booking_posts_columns', 'vrb_booking_table_head');
function vrb_booking_table_head( $defaults ) {
    global $VRBooking_var;
    $defaults['date_created']   = 'Date of Booking';
    $defaults['appartment']  = 'Property';          
    $defaults['date_from']    = 'Date from';
    $defaults['date_to']   = 'Date to';
    $defaults['price'] = 'Total amount, '.$VRBooking_var->settings['currency'];

    unset($defaults['date']);
    return $defaults;
}

add_action( 'manage_booking_posts_custom_column', 'vrb_booking_table_content', 10, 2 );
function vrb_booking_table_content( $column_name, $post_id ) {
    if ($column_name == 'appartment') {
    $app_id = get_post_meta( $post_id, '_booking_prop_id', true );
      echo  get_the_title($app_id);
    }
    if ($column_name == 'date_created') {
      if (get_post_meta( $post_id, '_booking_created', true ))
    echo date( "d/m/Y", get_post_meta( $post_id, '_booking_created', true ));
    }
    if ($column_name == 'date_from') {
      if (get_post_meta( $post_id, '_booking_date_from', true ))
    echo date( "d/m/Y", get_post_meta( $post_id, '_booking_date_from', true ));
    }
    if ($column_name == 'date_to') {
      if (get_post_meta( $post_id, '_booking_date_to', true ))
    echo date( "d/m/Y", get_post_meta( $post_id, '_booking_date_to', true ));
    }

    if ($column_name == 'price') {
    echo get_post_meta( $post_id, '_booking_price', true );
    }

}

////////////////////////////////

