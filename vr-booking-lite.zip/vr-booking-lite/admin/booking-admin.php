<?php

//  admin class
//

if ( ! defined( 'ABSPATH' ) )
	exit;

///// admin class for manage options

class VRBooking_admin
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueued_assets' ) );
        add_filter( 'custom_menu_order', array( $this, 'pms_submenu_order'));

        add_filter( 'posts_where', array( $this, 'search_where' ));
        add_filter( 'posts_join', array( $this, 'search_join' ));
        add_filter( 'posts_groupby', array( $this, 'search_group_by' ));

        add_action( 'current_screen', array( $this, 'current_screen_callback'));
        add_filter( 'post_updated_messages', array( $this, 'booking_updated_messages'));
        add_action( 'admin_init', array( $this, 'update_screen'));

       $this->c_element = 3;
    }
    
///////////////////////////////    

function enqueued_assets() {
         wp_enqueue_style( 'wp-color-picker');
         wp_enqueue_script( 'wp-color-picker');
        if(function_exists( 'wp_enqueue_media' )){
         wp_enqueue_media();
         } else {
           wp_enqueue_style('thickbox');
           wp_enqueue_script('media-upload');
           wp_enqueue_script('thickbox');
           }
    
     // wp_enqueue_script('jquery-ui-core');
     wp_enqueue_script('jquery-ui-datepicker');

     wp_enqueue_script( 'my-admin-custom-js', plugins_url( "admin/js/booking-admin.js", VR_BOOKING_PLUGIN ), array('jquery'), '1.0', true );
     wp_localize_script( 'my-admin-custom-js', 'lst', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce('lst-nonce')
         )
        );

      wp_enqueue_style('fontawesome2', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css', '', '4.6.3', 'all');
     wp_enqueue_style('jquery-ui-admin-style', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css', '', '1.12.1', 'all');
     wp_enqueue_style( 'booking-admin-style', plugins_url( "admin/css/booking-admin.css", VR_BOOKING_PLUGIN ));
     
     global $pagenow;
     
     if(isset($_GET['post_type']) && $_GET['post_type'] == 'property' && $pagenow == 'edit.php'){
       $cc = 4;
       $count = count(get_posts(array('post_type'   => 'property', 'numberposts' => -1 )));
       if ($count >= $this->c_element*$cc){
        $custom_css = ".wrap .page-title-action{display:none;}";
        wp_add_inline_style( 'booking-admin-style', $custom_css );
        }
     }
     
     if(isset($_GET['post_type']) && $_GET['post_type'] == 'booking' && $pagenow == 'edit.php'){
        $custom_css = ".wrap .page-title-action{display:none;}";
        wp_add_inline_style( 'booking-admin-style', $custom_css );
     }         
}

////////////////////////////////////
    /**
     * Add options page
     */
function add_plugin_page(){
        // This page will be under "Settings"
          add_menu_page(
            __('VR Booking Lite Settings', VR_BOOKING_TEXTDOMAIN),
            __('VR Booking Lite', VR_BOOKING_TEXTDOMAIN),
            'manage_options',
            'vr-booking-settings',
            array( $this, 'create_admin_page' ),
            '',
            26
        );

}

////////////////////////////////
function pms_submenu_order( $menu_ord )
{
    global $submenu;

    // Enable the next line to inspect the $submenu values
    //echo '<pre>'.print_r($submenu,true).'</pre>';
    $arr = array();
    //$arr[] = $submenu['edit.php?post_type=booking'][10];
    $arr[] = $submenu['edit.php?post_type=booking'][5];
    $submenu['edit.php?post_type=booking'] = $arr;

    return $menu_ord;
}

////////////////////////

function update_screen(){  
    global $pagenow;
    
    if(isset($_GET['post_type']) && $_GET['post_type'] == 'property'){
       $cc = 4;
       $count = count(get_posts(array('post_type' => 'property', 'numberposts' => -1 ))); 
       if ($count >= $this->c_element*$cc){
          if($pagenow == 'post-new.php'){ 
        wp_redirect(admin_url('edit.php?post_type=property'));
         exit;
        }
        if($pagenow == 'edit.php'){
          $page = remove_submenu_page( 'edit.php?post_type=property', 'post-new.php?post_type=property' );
        }     
       }
    }
    
    if(isset($_GET['post_type']) && $_GET['post_type'] == 'booking'){
        if($pagenow == 'post-new.php'){ 
        wp_redirect(admin_url('edit.php?post_type=booking'));
         exit;
        }
        if($pagenow == 'edit.php'){
          $page = remove_submenu_page( 'edit.php?post_type=booking', 'post-new.php?post_type=booking' );
        }     
    }
    
    return;
}    

///////////////////////////
function search_join ($join){
    global $pagenow, $wpdb;
    if ( isset( $_GET['s'] )){
    if ( is_admin() && $pagenow=='edit.php' && $_GET['post_type']=='booking' && $_GET['s'] != '') {
        $join .='LEFT JOIN '.$wpdb->postmeta. ' ON '. $wpdb->posts . '.ID = ' . $wpdb->postmeta . '.post_id ';
     }
    }
    return $join;
}

function search_where( $where ){
    global $pagenow, $wpdb;
    if ( isset( $_GET['s'] )){
    if ( is_admin() && $pagenow=='edit.php' && $_GET['post_type']=='booking' && $_GET['s'] != '') {
       // $start_date = $_GET['s'];
        $where = preg_replace(
       "/\(\s*".$wpdb->posts.".post_title\s+LIKE\s*(\'[^\']+\')\s*\)/",
       "(".$wpdb->posts.".post_title LIKE $1) OR ((".$wpdb->postmeta.".meta_key = 'range_from') AND (".$wpdb->postmeta.".meta_value LIKE $1))", $where );
     }
    }
    return $where;
}


function search_group_by($groupby) {
    global $pagenow, $wpdb;
    if ( isset( $_GET['s'] )){
      if ( is_admin() && $pagenow == 'edit.php' && $_GET['post_type']=='booking' && $_GET['s'] != '' ) {
        $groupby = "$wpdb->posts.ID";
      }
    }  
    return $groupby;
}

////////////////////////////

function booking_updated_messages($messages){
   global $post, $post_ID;

  $messages['booking'] = array(
    0 => '', // Unused. Messages start at index 1.
    1 => __('Reservation updated.'),
    2 => __('Custom field updated.'),
    3 => __('Custom field deleted.'),
    4 => __('Reservation updated.'),
    /* translators: %s: date and time of the revision */
    5 => isset($_GET['revision']) ? sprintf( __('Reservation restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
    6 => __('Reservation saved.'),
    7 => __('Reservation saved.'),
    8 => __('Reservation submitted.'),
    9 => sprintf( __('Reservation scheduled for: <strong>%1$s</strong>.'),
      // translators: Publish box date format, see http://php.net/date
      date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) )),
    10 => __('Reservation draft updated.'),
  );
  return $messages;
}

/////////////////////////
function current_screen_callback($screen) {
    if( is_object($screen) && $screen->post_type == 'booking' ) {
        add_filter('gettext', array( $this, 'wps_translation'), 10, 3);
    }
}

function wps_translation($translation, $text, $domain) {
        $translations = get_translations_for_domain( $domain);
        if ( $text == 'Published on: <b>%1$s</b>') {
            return $translations->translate( 'Created on: <b>%1$s</b>' );
        }
        if ( $text == 'Publish <b>immediately</b>') {
            return $translations->translate( 'Save <b>immediately</b>' );
        }
         if ( $text == 'Publish') {
            return $translations->translate( 'Save' );
        }
    return $translation;
}

///////////////////////////////////////    

    /**
     * Options page callback
     */
    function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'booking_settings' );
        ?>
        <div class="wrap">
            <h2><?php echo __('VR Booking Lite Settings', VR_BOOKING_TEXTDOMAIN); ?></h2>
            <form method="post" action="options.php">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'vr-booking-settings' );
                do_settings_sections( 'vr-booking-settings' );
                submit_button();
            ?>
            </form>
        </div>

        <script>
(function( $ ) {
	// Add Color Picker to all inputs that have 'color-field' class
	$(function() {
	$('.color-field').wpColorPicker();
	});
})( jQuery );
       </script>

        <?php
    }

////////////////////////////////////////////////
    /**
     * Register and add settings
     */
function page_init(){
        register_setting(
            'vr-booking-settings', // Option group
            'booking_settings', // Option name
            array( $this, 'sanitize' ) // Sanitize
);

///////// General

        add_settings_section(
            'setting_section_5', // ID
            __('General',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'print_section_info5' ), // Callback
            'vr-booking-settings' // Page
        );

        add_settings_field(
            'max_select_adults', // ID
            __('Maximum # of guests',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'max_select_adults_callback' ), // Callback
            'vr-booking-settings', // Page
            'setting_section_5' // Section
        );

        add_settings_field(
            'search_res_front', // ID
            __('Display per page (front page)',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'search_res_front_callback' ), // Callback
            'vr-booking-settings', // Page
            'setting_section_5' // Section
        );

        add_settings_field(
            'search_res_other', // ID
            __('Search results per page',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'search_res_other_callback' ), // Callback
            'vr-booking-settings', // Page
            'setting_section_5' // Section
        );

        add_settings_field(
            'color_button', // ID
            __('Adjust colors',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'color_button_callback' ), // Callback
            'vr-booking-settings', // Page
            'setting_section_5' // Section
        );

        ///////// Payment

        add_settings_section(
            'setting_section_3', // ID
            __('Payment settings',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'print_section_info3' ), // Callback
            'vr-booking-settings' // Page
        );

        add_settings_field(
            'currency', // ID
            __('Currency symbol ($, &euro; etc.)',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'currency_callback' ), // Callback
            'vr-booking-settings', // Page
            'setting_section_3' // Section
        );

        add_settings_field(
            'currency_code', // ID
            __('Currency 3 letters code (ISO 4217: USD, EUR, etc.)',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'currency_code_callback' ), // Callback
            'vr-booking-settings', // Page
            'setting_section_3' // Section
        );

        add_settings_field(
            'currency_place', // ID
            __('Place currency symbol',VR_BOOKING_TEXTDOMAIN), // Title
            array( $this, 'currency_place_callback' ), // Callback
            'vr-booking-settings', // Page
            'setting_section_3' // Section
        );
     
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    function sanitize( $input )
    {
        $new_input = array();

        $new_input['currency'] = sanitize_text_field($input['currency']);
        $new_input['currency_code'] = sanitize_text_field($input['currency_code']);
        $new_input['currency_place'] = intval($input['currency_place']);

        $new_input['max_select_adults'] = intval($input['max_select_adults']);
        $new_input['search_res_front'] = intval($input['search_res_front']);
        $new_input['search_res_other'] = intval($input['search_res_other']);
        $new_input['color_button'] = sanitize_text_field($input['color_button']);

        return $new_input;
    }

    /**
     * Print the Section text
     */

    function print_section_info2()
    {
        // echo __('Enter your settings below:', VR_BOOKING_TEXTDOMAIN);
    }

    function print_section_info3()
    {
        // echo __('Enter your settings below:', VR_BOOKING_TEXTDOMAIN);
    }

    function print_section_info5()
    {
        // echo __('Enter your settings below:', VR_BOOKING_TEXTDOMAIN);
    }

    function max_select_adults_callback(){
        printf(
            '<input type="text" id="max_select_adults" name="booking_settings[max_select_adults]" value="%s" />',
            isset( $this->options['max_select_adults'] ) ? esc_attr( $this->options['max_select_adults']) : '7'
        );
    }

    function search_res_front_callback(){
        printf(
            '<input type="text" id="search_res_front" name="booking_settings[search_res_front]" value="%s" />',
            isset( $this->options['search_res_front'] ) ? esc_attr( $this->options['search_res_front']) : '6'
        );
    }

    function search_res_other_callback(){
        printf(
            '<input type="text" id="search_res_other" name="booking_settings[search_res_other]" value="%s" />',
            isset( $this->options['search_res_other'] ) ? esc_attr( $this->options['search_res_other']) : '10'
        );
    }

    function color_button_callback(){
        printf(
            '<input type="text" id="color_button" class="color-field" name="booking_settings[color_button]" value="%s" />',
            isset( $this->options['color_button'] ) ? esc_attr( $this->options['color_button']) : '#81d742'
        );
    }

    function currency_callback(){
        printf(
            '<input type="text" id="currency" name="booking_settings[currency]" value="%s" />',
            isset( $this->options['currency'] ) ? esc_attr( $this->options['currency']) : '$'
        );
    }

    function currency_code_callback(){
        printf(
            '<input type="text" id="currency" name="booking_settings[currency_code]" value="%s" />',
            isset( $this->options['currency_code'] ) ? esc_attr( $this->options['currency_code']) : 'USD'
        );
    }

    function currency_place_callback(){

        $check = isset($this->options['currency_place']) ?  $this->options['currency_place'] : 1;

        $checked1 = '';
        $checked2 = '';
        if ($check==1) $checked1 = 'checked';
           else $checked2 = 'checked';

        echo '<p><input id="booking_settings[currency_place]1" name="booking_settings[currency_place]" type="radio" value="1" '.$checked1.'/><label id="booking_settings_currency_place1" for="booking_settings[currency_place]1">'.__('Before amount', VR_BOOKING_TEXTDOMAIN).'</label></p>';
       echo '<p><input id="booking_settings[currency_place]2" name="booking_settings[currency_place]" type="radio" value="2" '.$checked2.'/><label id="booking_settings_currency_place2" for="booking_settings[currency_place]2">'.__('After amount', VR_BOOKING_TEXTDOMAIN).'</label></p>';

    }
    
/////////// End of Class

}

	$VRBooking_admin = new VRBooking_admin();


