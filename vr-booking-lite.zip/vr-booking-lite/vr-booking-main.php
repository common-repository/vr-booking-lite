<?php

//     Plugin Main class

if ( ! defined( 'ABSPATH' ) )
	exit;

/////// make our main plugin class

class VRBooking {
    public $settings = array();
    public $markers_urls = array();
    public function __construct() {

        global $wpdb;
        $this->db = $wpdb;

        $this->home_url = get_home_url();

        add_action( 'plugins_loaded', array( $this, 'load_textdomain' ));
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueued_assets') );

        add_filter( 'redirect_canonical', array( $this, 'disable_my_canonical_redirect_for_front_page' ), 10, 2);
        add_filter( 'query_vars', array( $this, 'register_query_var') );
        //add rewrite rules in case another plugin flushes rules
        // Call when plugin is initialized on every page load
        add_action( 'init', array( $this, 'rewrite_rule'), 10, 0 );

        add_action( 'init', array( $this, 'create_booking_post_type'), 0);
        add_action( 'init', array( $this, 'create_property_post_type'), 0);

        add_filter( 'single_template',  array( $this, 'custom_property_template') );

        add_action( 'cmb2_admin_init', array( $this, 'cmb2_metaboxes') );

        add_action( 'template_redirect', array( $this, 'redirect_after_post'));

        add_action('wp_ajax_select_ap', array( $this, 'select_ap_callback'));
        add_action('wp_ajax_select_ap2', array( $this, 'select_ap2_callback'));
        add_action('wp_ajax_update_general_p', array( $this, 'update_general_p_callback'));
        add_action('wp_ajax_get_amount_booking', array( $this, 'get_amount_booking_callback'));

        add_action('wp_ajax_check_ap', array( $this, 'check_ap_callback'));

        add_action( 'save_post', array( $this, 'update_booking_title'), 10, 3 );

        register_activation_hook( VR_BOOKING_PLUGIN, array( $this, 'install') );
        register_deactivation_hook( VR_BOOKING_PLUGIN, array( $this, 'deactivation') );

        add_shortcode( 'booking-home', array( $this, 'home_page_shortcode') );
        add_shortcode( 'booking-search', array( $this, 'search_page_shortcode') );
        add_shortcode( 'booking-booking', array( $this, 'booking_page_shortcode') );
        add_shortcode( 'booking-thanks', array( $this, 'thanks_page_shortcode') );

        add_shortcode( 'booking-property', array( $this, 'property_page_shortcode') );

        /**************** init settings *******************/
       $this->settings = get_option('booking_settings');
       if(empty($this->settings)) {
       $this->settings['tax'] = '';
       $this->settings['currency'] = '$';
       $this->settings['currency_code'] = 'USD';
       $this->settings['currency_place'] = 1;
       $this->settings['max_select_adults'] = 7;
       $this->settings['search_res_front'] = 6;
       $this->settings['search_res_other'] = 10;
       $this->settings['color_button'] = '#81d742';
       update_option('booking_settings', $this->settings);
       }
}

public function install() {
    
    $this->create_page( 'search-result', 'VR_BOOKING_page_search_result', __('Available properties', 'booking'), '[booking-search]');
    $this->create_page( 'booking', 'VR_BOOKING_page_booking', __('Booking', VR_BOOKING_TEXTDOMAIN), '[booking-booking]');
    $this->create_page( 'services', 'VR_BOOKING_page_services', __('Services', VR_BOOKING_TEXTDOMAIN), '[booking-services]');
    $this->create_page( 'thank-you', 'VR_BOOKING_page_thank_you', __('Confirmation', VR_BOOKING_TEXTDOMAIN), '<h3>'.__('Thank you for your request, one of our staff will respond shortly.', VR_BOOKING_TEXTDOMAIN).'</h3>
[booking-thanks]');
 
   $this->create_booking_post_type();
   $this->create_property_post_type();
    $this->rewrite_rule();
   // flush_rewrite_rules();
    
    global $wp_rewrite;
    $wp_rewrite->flush_rules();
}

function deactivation() {
   	flush_rewrite_rules();
 /* 
    wp_delete_post(get_option('VR_BOOKING_page_search_result'));
    wp_delete_post(get_option('VR_BOOKING_page_booking'));
    wp_delete_post(get_option('VR_BOOKING_page_thank_you'));
    delete_option('VR_BOOKING_page_search_result');
    delete_option('VR_BOOKING_page_booking');
    delete_option('VR_BOOKING_page_thank_you');
    */
    
    delete_option('VR_BOOKING_VERSION_LIGHT'); 
}

function disable_my_canonical_redirect_for_front_page( $redirect_url, $requested_url ) {
    if( is_front_page() )
        return $requested_url;
    else
        return $redirect_url;
}

function create_page( $slug, $option, $page_title = '', $page_content = '', $post_parent = 0 ) {
    global $wpdb;
    $option_value = get_option( $option );
    if ( $option_value > 0 && get_post( $option_value ) )
      return;
    $page_found = $wpdb->get_var("SELECT ID FROM " . $wpdb->posts . " WHERE post_name = '$slug' LIMIT 1;");
    if ( $page_found ) :
      if ( ! $option_value )
        update_option( $option, $page_found );
      return;
    endif;
    $page_data = array(
          'post_status' 		=> 'publish',
          'post_type' 		=> 'page',
          'post_author' 		=> 1,
          'post_name' 		=> $slug,
          'post_title' 		=> $page_title,
          'post_content' 		=> $page_content,
          'post_parent' 		=> $post_parent,
          'comment_status' 	=> 'closed'
      );
      $page_id = wp_insert_post( $page_data );
      update_option( $option, $page_id );
}

////////////////////////////////////////////

function load_textdomain() {
      load_plugin_textdomain( VR_BOOKING_TEXTDOMAIN,  false, VR_BOOKING_PLUGIN_DIR . '/languages' );
}

function enqueued_assets() {
      wp_enqueue_style( 'datetimepicker-style', plugins_url( "js/jquery.datetimepicker.css", VR_BOOKING_PLUGIN ));
      wp_enqueue_script( 'datetimepicker-js', plugins_url( "js/jquery.datetimepicker.full.min.js", VR_BOOKING_PLUGIN ), array('jquery'), '1.0', true );
     wp_enqueue_script( 'jqvalidate-js', plugins_url( "js/jquery.validate.min.js", VR_BOOKING_PLUGIN ), array('jquery'), '1.0', true );
     // //wp_enqueue_script( 'jqvalidate-local-js', plugins_url( "js/localization/messages_es.min.js", VR_BOOKING_PLUGIN ), array('jquery'), '1.0', true );
     wp_enqueue_script( 'my-custom-js', plugins_url( "js/booking-settings.js", VR_BOOKING_PLUGIN ), array('jquery'), '1.0', true );
     wp_localize_script( 'my-custom-js', 'lst', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce('lst-nonce')
         )
        );

     wp_enqueue_style( 'booking-style', plugins_url( "css/booking.css", VR_BOOKING_PLUGIN ));

     $color = $this->settings['color_button'];
        $custom_css = "
                input[type=\"button\"].bc-button-color, input[type=\"submit\"].bc-button-color, .rr_form_input input[type=\"submit\"], #pager span.cur_page, #app-page .doc_tab.cur_tab {
                        background-color: {$color};
                }
                #sort_by_block{
                   background-color: {$color};
                   color: #fff;
                }

                #app-page .doc_tab{
                        color: {$color};
                        border-color: {$color};
                }

                #app-page .doc_tab:nth-child(1){
                        border-color: {$color};
                }
                .add_service_block{
                       border-color: {$color};
                }";
        wp_add_inline_style( 'booking-style', $custom_css );
}

function custom_property_template($single_template) {
     global $post;

     if ($post->post_type == 'property' ) {
          $single_template = plugin_dir_path(__FILE__) . 'templates/single-property.php';
     }
     return $single_template;
     wp_reset_postdata();
}

function register_query_var( $vars ) {
      // $vars[] = 'user_login';
      $vars[] = 'reserv_code';
      $vars[] = 'page_num';
       return $vars;
}

function rewrite_rule() {
        add_rewrite_rule( 'thank-you/reserv-code/([^/]+)/?', 'index.php?pagename=thank-you&reserv_code=$matches[1]', 'top' );
        add_rewrite_rule( 'page_num/([^/]+)/sort_by/([^/]+)/?', 'index.php?pagename=home-page&page_num=$matches[1]&sort_by=$matches[2]', 'top' );
        add_rewrite_rule( 'page_num/([^/]+)/?', 'index.php?pagename=home-page&page_num=$matches[1]', 'top' );
        add_rewrite_rule( 'search-result/page_num/([^/]+)/sort_by/([^/]+)/?', 'index.php?pagename=search-result&page_num=$matches[1]&sort_by=$matches[2]', 'top' );
        add_rewrite_rule( 'search-result/page_num/([^/]+)/?', 'index.php?pagename=search-result&page_num=$matches[1]', 'top' );
}

///////////////////

function redirect_after_post(){

if (!empty($_POST['guote'])){
   if ((empty($_POST['adults']) || empty($_POST['date_from']) || empty($_POST['date_to'])) || (strtotime($this->date_to_sql($_POST['date_from']) . ' 00:00:00') >= strtotime($this->date_to_sql($_POST['date_to']) . ' 00:00:00'))){
     wp_safe_redirect(get_home_url());
     exit;
   }
}

    if (empty($_POST['reserve']) && !empty($_POST['book'])){
    //print_r($_POST);
    if (!empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['email']) && !empty($_POST['tel1']) && !empty($_POST['date_from']) && !empty($_POST['date_to']) && $this->validate_date($_POST['date_from']) && $this->validate_date($_POST['date_to'])) // Validate our dates in the $_POST
    { 
        
      $post_id = intval($_POST['id']);
      
      // Here we have all $_POST['date_from'] and $_POST['date_to'] - validated  

      if ($this->is_free_appartment($_POST['date_from'], $_POST['date_to'], $post_id)){
      $reserv_id = $this->create_booking($_POST['date_from'], $_POST['date_to']);
      $reserv_code = get_the_title($reserv_id);
           $this->accept_booking($reserv_code, 0, '', 'cash');
           $home_url = get_home_url();
           $Path='/thank-you/reserv-code/'.$reserv_code;
           wp_safe_redirect($home_url.$Path);
           exit;
       }
    }
  }

}

///////////////////

////// validate format dd/mm/yyyy bool checkdate ( int $month , int $day , int $year )

function validate_date($test_date){
   $output = true;
   
   $date_arr  = explode('/', $test_date);
   if (sizeof($date_arr) != 3 || !checkdate($date_arr[1], $date_arr[0], $date_arr[2])){
      $output = false;
   }
    
   return $output;
}

///////////////

public function format_currency($amount){
  $output = '';

  if ( $this->settings['currency_place'] == 1 )
    $output .= $this->settings['currency'].$amount;
  else
    $output .= $amount.' '.$this->settings['currency'];

  return $output;
}

///////////////////////////////////

public function accept_booking($reserv_code, $paid = 0, $token = '', $paid_by = ''){

     $page = get_page_by_title( $reserv_code, OBJECT, 'booking' );

     if (!empty($page)){
     $booking_id = $page->ID;

     $post_id = get_post_meta($booking_id, '_booking_prop_id', true);

     update_post_meta($post_id, '_booking_accepted', 1);
     update_post_meta($post_id, '_booking_paid', $paid);
     update_post_meta($post_id, '_booking_paid_by', $paid_by);
     update_post_meta($post_id, '_booking_token', $token);
    }
}

///////////////

function update_general_p_callback(){

   $ap_id = intval($_POST['select_ap']);
   $general_price = floatval($_POST['general_price']);

  update_post_meta($ap_id, 'general_price', $general_price);

  $rates = $this->get_all_rates_by_ap_id($ap_id);

  echo json_encode($rates);

  wp_die();
}

function check_ap_callback(){

  if ( $this->validate_date($_POST['date_from']) && $this->validate_date($_POST['date_to']) && $this->is_free_appartment($_POST['date_from'], $_POST['date_to'], intval($_POST['id'])))
  echo 1;
  else
  echo 0;

  wp_die();
}

function select_ap_callback(){

   $ap_id = intval($_POST['select_ap']);

    // get new rates dates array, output

    $rates = $this->get_all_rates_by_ap_id($ap_id);

  echo json_encode($rates);
  wp_die();
}

function select_ap2_callback(){

   $ap_id = intval($_POST['select_ap']);

    // get new rates dates array, output

    $rates = $this->get_all_rates_by_ap_id($ap_id);
    $av = $this->get_av_dates_by_ap_id($ap_id);

    $output = array_merge($rates, $av);

  echo json_encode($output);
  wp_die();
}

function get_amount_booking_callback(){

   $ap_id = intval($_POST['id']);

   $output = array();

   if ( !empty($_POST['date_from']) && !empty($_POST['date_to'])  && $this->validate_date($_POST['date_from']) && $this->validate_date($_POST['date_to'])){
    $rates = $this->get_all_rates_by_ap_id($ap_id, $this->date_to_sql($_POST['date_from']), $this->date_to_sql($_POST['date_to']));
   $output = $rates;
   } else
   $output = array('total' => '', 'total_tax' => '', 'total_clear' => '');

   echo json_encode($output);

  wp_die();
}

/////////////////////////

function get_av_dates_by_ap_id($ap_id){
   $output = array();
   $av_arr = array();
   $booking_from_arr = array();

   $now = time() - 365*24*60*60;
   $to =  time() + 2*365*24*60*60;
   $begin_date = date("Y-m-d", $now);
   $end_date = date("Y-m-d", $to);

      $begin = new DateTime( $begin_date );
      $end = new DateTime( $end_date );
      $end = $end->modify( '+1 day' );

      $interval = new DateInterval('P1D');
      $daterange = new DatePeriod($begin, $interval ,$end);
      foreach($daterange as $date){
       $av_arr[strtotime($date->format("Y-m-d"))] = 0;
       $booking_from_arr[strtotime($date->format("Y-m-d"))] = '';
      }

   $args = array(
               'post_type' => 'booking',
               'posts_per_page'=> -1,
               'meta_query' => array(
                  'relation' => 'AND',
                  'date_from' => array(
                    'key'     => '_booking_date_from',
                    'value'   => $to,
                    'compare' => '<=',
                    'type'    => 'NUMERIC',
                    ),
                  'date_to' => array(
                    'key'     => '_booking_date_to',
                    'value'   => $now,
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                    ),
                  'ap_id' => array(
                    'key'     => '_booking_prop_id',
                    'value'   => $ap_id,
                    'compare' => '=',
                    ),
                   ),
                  );

    $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) : $the_query->the_post();
      $begin_date = date("Y-m-d", get_post_meta( get_the_ID(), '_booking_date_from', true ));
      $end_date = date("Y-m-d", get_post_meta( get_the_ID(), '_booking_date_to', true ));
      
      $booking_from = get_post_meta( get_the_ID(), '_booking_from', true );
      
      $booking_from_name = $booking_from ? $booking_from : __( 'Site', VR_BOOKING_TEXTDOMAIN);

      $begin = new DateTime( $begin_date );
      $end = new DateTime( $end_date );
      $end = $end->modify( '+1 day' );

      $interval = new DateInterval('P1D');
      $daterange = new DatePeriod($begin, $interval ,$end);

      $first = true;
      //$last = false;
      foreach($daterange as $date){
         $cur = strtotime($date->format("Y-m-d"));
         $prev = $av_arr[$cur];
         $prev_booking_from = $booking_from_arr[$cur];
      if ($first){
         if ($av_arr[$cur]) $av_arr[$cur] = 4;
         else
         $av_arr[$cur] = 2;
         $first = false;
       } else
       $av_arr[$cur] = 3;
       $booking_from_arr[$cur] = $booking_from_name;
      }
       if ($prev > 0)
       $av_arr[$cur] = 4;
       else
       $av_arr[$cur] = 1;
       $booking_from_arr[$cur] = $prev_booking_from;

     endwhile;
wp_reset_postdata();

   $output['av_arr'] = $av_arr;
   $output['booking_from_arr'] = $booking_from_arr;
   return $output;
}

////////////////////////

function get_all_rates_by_ap_id($ap_id, $range_from = '', $range_to = '', $extra_bed = ''){
    $output = array();
    $price_arr = array();
    $color_arr = array();
    $price = 0;
    $price_tax = 0;
    $price_clear = 0;
    $min_price = 1000000;
    $general_price = 0;
    $general_price_clear = 0;
    $total_count = 0;
    $nights_total = 0;
    $tax = 1;

    $deposit = 0;

    if (!empty($this->settings['tax']))
    $tax_am = floatval($this->settings['tax'])/100;
    else $tax_am = 0;

    $tax = $tax + $tax_am;

              $ap_fields = get_post_custom($ap_id);
              if (isset($ap_fields['general_price'])){
              $general_price = round($ap_fields['general_price'][0]*$tax, 2);
              $general_price_clear = round($ap_fields['general_price'][0], 2);
              }

  if (!$range_from){
  $range_rates_from = date("Y-m-d", time() - 365*24*60*60);
  $range_rates_to = date("Y-m-d", time() + 2*365*24*60*60);
  } else {
   $range_rates_from = $range_from;
   $range_rates_to = $range_to;
  }

    $nights_total = date_diff(date_create($range_rates_from. ' 00:00:00'), date_create($range_rates_to. ' 00:00:00'))->days;

      // no rates, so get general price

      $begin_date = $range_rates_from;
      $end_date = $range_rates_to;

      $begin = new DateTime( $begin_date );
      $end = new DateTime( $end_date );

      if (!$range_from)
      $end = $end->modify( '+1 day' );

      $interval = new DateInterval('P1D');
      $daterange = new DatePeriod($begin, $interval ,$end);

      foreach($daterange as $date){
            $total_count++;
            $price_arr[strtotime($date->format("Y-m-d"))] = $general_price;
      }
          $min_price = $general_price;
          $price = $general_price*$nights_total;
          $price_tax = round($general_price_clear*$tax_am, 2)*$nights_total;
          $price_clear = $general_price_clear*$nights_total;
          

   if (($range_from)and($total_count < $nights_total)){
       $price = $price + ($nights_total - $total_count)*$general_price;
       $price_tax = $price_tax + ($nights_total - $total_count)*round($general_price_clear*$tax_am, 2);
       $price_clear = $price_clear + ($nights_total - $total_count)*$general_price_clear;
   }

   if ($total_count < $nights_total){
       if ($min_price > $general_price) $min_price = $general_price;
   }

  if ($min_price == 1000000) $min_price = 0;

  $output['nights_total_clear'] = $price_clear;
  $output['nights_total_tax'] = $price_tax;
  $output['nights_total'] = $price;
  $output['total'] = $price;
  $output['total_tax'] = $price_tax;
  $output['total_clear'] = $price_clear;
  $output['price_arr'] = $price_arr;
  $output['min'] = $min_price;
  $output['general_price'] = $general_price;
  $output['color_arr'] = $color_arr;

  return $output;
}

/////////////////////////////////////

function create_property_post_type(){

// Set UI labels for Custom Post Type
	$labels = array(
		'name'                => _x( 'Properties', 'Post Type General Name', VR_BOOKING_TEXTDOMAIN),
		'singular_name'       => _x( 'Property', 'Post Type Singular Name', VR_BOOKING_TEXTDOMAIN),
		'menu_name'           => __( 'Properties', VR_BOOKING_TEXTDOMAIN),
		'parent_item_colon'   => __( 'Parent Property', VR_BOOKING_TEXTDOMAIN),
		'all_items'           => __( 'All Properties', VR_BOOKING_TEXTDOMAIN),
		'view_item'           => __( 'View Property', VR_BOOKING_TEXTDOMAIN),
		'add_new_item'        => __( 'Add New Property', VR_BOOKING_TEXTDOMAIN),
		'add_new'             => __( 'Add New', VR_BOOKING_TEXTDOMAIN),
		'edit_item'           => __( 'Edit Property', VR_BOOKING_TEXTDOMAIN),
		'update_item'         => __( 'Update Property', VR_BOOKING_TEXTDOMAIN),
		'search_items'        => __( 'Search Properties', VR_BOOKING_TEXTDOMAIN),
		'not_found'           => __( 'Not Found', VR_BOOKING_TEXTDOMAIN),
		'not_found_in_trash'  => __( 'Not found in Trash', VR_BOOKING_TEXTDOMAIN),
	);

// Set other options for Custom Post Type

	$args = array(
		'label'               => __( 'properties', VR_BOOKING_TEXTDOMAIN),
		'description'         => __( 'Properties', VR_BOOKING_TEXTDOMAIN),
		'labels'              => $labels,
		// Features this CPT supports
		'supports'            => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
        'menu_position'        => 27,
        'menu_icon'           => 'dashicons-building',
		'show_in_nav_menus'   => false,
		'show_in_admin_bar'   => true,
		'can_export'          => true,
		'has_archive'         => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);

	// Registering your Custom Post Type
	register_post_type( 'property', $args );

}

function create_booking_post_type(){

// Set UI labels for Custom Post Type
	$labels = array(
		'name'                => _x( 'All Reservations', 'Post Type General Name', VR_BOOKING_TEXTDOMAIN),
		'singular_name'       => _x( 'Reservation', 'Post Type Singular Name', VR_BOOKING_TEXTDOMAIN),
		'menu_name'           => __( 'Reservations', VR_BOOKING_TEXTDOMAIN),
		'parent_item_colon'   => __( 'Parent Reservation', VR_BOOKING_TEXTDOMAIN),
		'all_items'           => __( 'All Reservations', VR_BOOKING_TEXTDOMAIN),
		'view_item'           => __( 'View Reservation', VR_BOOKING_TEXTDOMAIN),
		'add_new_item'        => __( 'Make New Reservation', VR_BOOKING_TEXTDOMAIN),
		'add_new'             => __( 'Make New Reservation', VR_BOOKING_TEXTDOMAIN),
		'edit_item'           => __( 'Modify Reservation', VR_BOOKING_TEXTDOMAIN),
		'update_item'         => __( 'Update Reservation', VR_BOOKING_TEXTDOMAIN),
		'search_items'        => __( 'Search Reservations', VR_BOOKING_TEXTDOMAIN),
		'not_found'           => __( 'Not Found', VR_BOOKING_TEXTDOMAIN),
		'not_found_in_trash'  => __( 'Not found in Trash', VR_BOOKING_TEXTDOMAIN),
	);

// Set other options for Custom Post Type

	$args = array(
		'label'               => __( 'bookings', VR_BOOKING_TEXTDOMAIN),
		'description'         => __( 'Reservations', VR_BOOKING_TEXTDOMAIN),
		'labels'              => $labels,
		// Features this CPT supports
		'supports'            => array('title'),
		'hierarchical'        => false,
		'public'              => false,
		'show_ui'             => true,
		'show_in_menu'        => true,
        'menu_position'        => 31,
        'menu_icon'           => 'dashicons-calendar-alt',
		'show_in_nav_menus'   => false,
		'show_in_admin_bar'   => true,
		'can_export'          => true,
		'has_archive'         => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'capability_type'     => 'post',
	);

	// Registering your Custom Post Type
	register_post_type( 'booking', $args );

    // remove_post_type_support( 'booking', 'title' );
}

/**
 * Define the metabox and field configurations.
 */
function cmb2_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = '_property_';

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'property_metabox',
        'title'         => __( 'Other Fields', VR_BOOKING_TEXTDOMAIN ),
        'object_types'  => array( 'property', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );

    // Regular text field
    $cmb->add_field( array(
        'name'       => __( 'Address', VR_BOOKING_TEXTDOMAIN ),
        'desc'       => __( 'Street, etc.', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'address',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
        //'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
        // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
        // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
        // 'on_front'        => false, // Optionally designate a field to wp-admin only
        // 'repeatable'      => true,
    ) );

    // Regular text field
    $cmb->add_field( array(
        'name'       => __( 'Size', VR_BOOKING_TEXTDOMAIN ),
       // 'desc'       => __( 'Street, etc.', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'size',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb->add_field( array(
        'name'       => __( '# of beds', VR_BOOKING_TEXTDOMAIN ),
       // 'desc'       => __( 'Street, etc.', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'max_beds',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb->add_field( array(
        'name'       => __( '# of rooms', VR_BOOKING_TEXTDOMAIN ),
       // 'desc'       => __( 'Street, etc.', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'n_rooms',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb->add_field( array(
        'name'       => __( 'Max # of Guests', VR_BOOKING_TEXTDOMAIN ),
       // 'desc'       => __( 'Street, etc.', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'max_guests',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb->add_field( array(
        'name'       => sprintf(__( 'Price, %s', VR_BOOKING_TEXTDOMAIN ), $this->settings['currency']),
       // 'desc'       => __( 'Street, etc.', VR_BOOKING_TEXTDOMAIN ),
        'id'         => 'general_price',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $prefix = '_booking_';

    $cmb3 = new_cmb2_box( array(
        'id'            => 'booking_metabox',
        'title'         => __( '&nbsp;', VR_BOOKING_TEXTDOMAIN ),
        'object_types'  => array( 'booking', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );

    $cmb3->add_field( array(
    'name'       => __( 'Select Property', VR_BOOKING_TEXTDOMAIN ),
   // 'desc'       => __( 'field description (optional)', VR_BOOKING_TEXTDOMAIN ),
    'id'         => $prefix . 'prop_id',
    'type'       => 'select',
    'options_cb' => 'vrb_cmb2_get_property_options',
    'show_option_none' => true,
    'attributes'  => array(
         'required'    => 'required',
         ),
    'after_field' => array($this, 'cmb2_after_row'), // callback
    ) );

    $cmb3->add_field( array(
    'name' => __( 'Date from', VR_BOOKING_TEXTDOMAIN ),
    'id'   => $prefix . 'date_from',
    'type' => 'hidden',
    ) );

    $cmb3->add_field( array(
    'name' => __( 'Date to', VR_BOOKING_TEXTDOMAIN ),
    'id'   => $prefix . 'date_to',
    'type' => 'hidden',
    ) );

    $cmb3->add_field( array(
    'name' => __( 'Date to', VR_BOOKING_TEXTDOMAIN ),
    'id'   => $prefix . 'price_tax',
    'type' => 'hidden',
    ) );

    $cmb3->add_field( array(
    'name' => __( 'Date to', VR_BOOKING_TEXTDOMAIN ),
    'id'   => $prefix . 'price_clear',
    'type' => 'hidden',
    ) );

    $cmb3->add_field( array(
    'name' => __( 'Date from', VR_BOOKING_TEXTDOMAIN ),
    'id'   => 'range_from',
    'type' => 'text',
    'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb3->add_field( array(
    'name' => __( 'Date to', VR_BOOKING_TEXTDOMAIN ),
    'id'   => 'range_to',
    'type' => 'text',
    'attributes'  => array(
         'required'    => 'required',
         ),
    ) );


    $cmb3->add_field( array(
        'name'       => sprintf(__( 'Total amount, %s', VR_BOOKING_TEXTDOMAIN ), $this->settings['currency']),
        'id'         => $prefix . 'price',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
         'after_field' => array($this, 'cmb2_after_row_amount'), // callback
    ) );

    $cmb3->add_field( array(
        'name'       => __( 'First name', VR_BOOKING_TEXTDOMAIN ),
        //'desc'       => __( 'digits only', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'first_name',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb3->add_field( array(
        'name'       => __( 'Last name', VR_BOOKING_TEXTDOMAIN ),
        //'desc'       => __( 'digits only', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'last_name',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb3->add_field( array(
        'name'       => __( 'No. Guests', VR_BOOKING_TEXTDOMAIN ),
        //'desc'       => __( 'digits only', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'n_adults',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb3->add_field( array(
        'name'       => __( 'E-mail', VR_BOOKING_TEXTDOMAIN ),
        //'desc'       => __( 'digits only', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'email',
        'type'       => 'text_email',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

    $cmb3->add_field( array(
        'name'       => __( 'Phone', VR_BOOKING_TEXTDOMAIN ),
        //'desc'       => __( 'digits only', VR_BOOKING_TEXTDOMAIN ),
        'id'         => $prefix . 'phone',
        'type'       => 'text',
        'attributes'  => array(
         'required'    => 'required',
         ),
    ) );

}

/////////////////

function cmb2_after_row(){

 echo '<h4>'.__( 'Availability calendar', VR_BOOKING_TEXTDOMAIN ).'</h4>
      <div id="av_calendar"></div>';

}

function cmb2_after_row_amount(){

 echo '<div id="spin_date_from"></div>';

}

//////////////////////
function update_booking_title( $post_id, $post, $update ) {

    $slug = 'booking';
    // If this isn't a 'catalog_item' post, don't update it.
    if (( $slug != $post->post_type )||( ! is_admin() )) {
        return;
    }

    $prop_id = get_post_meta( $post_id, '_booking_prop_id', true );
    $price_arr = $this->get_all_rates_by_ap_id($prop_id, $this->date_to_sql(get_post_meta( $post_id, 'range_from', true )), $this->date_to_sql(get_post_meta( $post_id, 'range_to', true )));
    update_post_meta($post_id, '_booking_price_tax', $price_arr['total_tax']);
    update_post_meta($post_id, '_booking_price_clear', $price_arr['total_clear']);
    update_post_meta($post_id, '_booking_nights_price', $price_arr['nights_total']);
    update_post_meta($post_id, '_booking_nights_price_tax', $price_arr['nights_total_tax']);
    update_post_meta($post_id, '_booking_nights_price_clear', $price_arr['nights_total_clear']);

    if (strpos( $post->post_title , '-')) {
        return;
    }

  update_post_meta($post_id, '_booking_accepted', 1);
  update_post_meta($post_id, '_booking_paid', 0);
  update_post_meta($post_id, '_booking_paid_by', 'cash');
  update_post_meta($post_id, '_booking_token', '');
  update_post_meta($post_id, '_booking_created', time());
  update_post_meta($post_id, '_booking_from', 0);
  $user_id = $this->create_customer();

    $title = date('ymd').'-'.date('His').mt_rand(10, 99);

    $my_post = array(
      'ID'           => $post_id,
      'post_title'   => $title,
  );
  wp_update_post( $my_post );

}

/////////////////

function create_customer(){
  $output = 0;

    if ((!empty($_POST['email']))||(!empty($_POST['_booking_email']))){

         if (!empty($_POST['email'])){
         $email = sanitize_email($_POST['email']);
         $first_name = sanitize_text_field($_POST['first_name']);
         $last_name = sanitize_text_field($_POST['last_name']);
         $tel1 = sanitize_text_field($_POST['tel1']);
         } else {
         $email = sanitize_email($_POST['_booking_email']);
         $first_name = sanitize_text_field($_POST['_booking_first_name']);
         $last_name = sanitize_text_field($_POST['_booking_last_name']);
         $tel1 = sanitize_text_field($_POST['_booking_phone']);
         }

        $user_id = username_exists( $email );
        if ( !$user_id and email_exists($email) == false ) {
          $random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
          $user_id = wp_create_user( $email, $random_password, $email );
          $output = $user_id;

          wp_update_user(
          array(
          'ID'       => $user_id,
          'nickname' => $email,
          'display_name' => $first_name.' '.$last_name,
          )
          );
          $user = new WP_User( $user_id );
          $user->set_role( 'subscriber' );

          update_user_meta($user_id, 'email', $email);

          } else {
            $output = $user_id;
            wp_update_user(
            array(
            'ID'       => $user_id,
            'display_name' => $first_name.' '.$last_name,
           )
          );
            }
          update_user_meta($user_id, 'first_name', $first_name);
          update_user_meta($user_id, 'last_name', $last_name);
          update_user_meta($user_id, 'tel1', $tel1);
    }
  return $output;
}

/////////////////////////////////

function create_booking($date_from, $date_to){

       $post_id = 0;
       $user_id = $this->create_customer();

       if ($user_id){

       $price_arr = $this->get_all_rates_by_ap_id(intval($_POST['id']), $this->date_to_sql($_POST['date_from']), $this->date_to_sql($_POST['date_to']));  

       $post_id = wp_insert_post(array (
    'post_type' => 'booking',
    'post_title' => date('ymd').'-'.date('His').mt_rand(10, 99),
    'post_content' => '',
    'post_status' => 'publish',
    'comment_status' => 'closed',
    'post_author'   => 1,
    'meta_input'   => array(
        '_booking_prop_id' => intval($_POST['id']),
        '_booking_phone' => sanitize_text_field($_POST['tel1']),
        '_booking_email' => sanitize_email($_POST['email']),
        '_booking_n_adults' => intval($_POST['adults']),
        '_booking_first_name' => sanitize_text_field($_POST['first_name']),
        '_booking_last_name' => sanitize_text_field($_POST['last_name']),
        '_booking_date_from' => strtotime($this->date_to_sql($_POST['date_from'])),
        '_booking_date_to' => strtotime($this->date_to_sql($_POST['date_to'])),
        'range_from' => $date_from,
        'range_to' => $date_to,
        '_booking_price' => $price_arr['total'],
        '_booking_price_tax' => $price_arr['total_tax'],
        '_booking_price_clear' => $price_arr['total_clear'],
        '_booking_nights_price' => $price_arr['nights_total'],
        '_booking_nights_price_tax' => $price_arr['nights_total_tax'],
        '_booking_nights_price_clear' => $price_arr['nights_total_clear'],
        '_booking_accepted' => 0,
        '_booking_paid' => 0,
        '_booking_paid_by' => '',
        '_booking_token' => '',
        '_booking_created' => time(),
        '_booking_from' => 0,
    ),
       ));

    do_action('vrb_create_booking', $post_id);
     }
  return $post_id;
}

////////// Thank You page  /////

function thanks_page_shortcode(){

   $output = '';

   $reserv_code = '';
    if (!empty($_POST['custom'])) $reserv_code = $_POST['custom'];
    elseif (get_query_var('reserv_code')) $reserv_code = get_query_var('reserv_code');

     if ($reserv_code){

      //$reserv_code = get_query_var('reserv_code');

     // $this->thanks_email($reserv_code);

      $page = get_page_by_title( $reserv_code, OBJECT, 'booking' );

      if (!empty($page)){
      $post_id = get_post_meta( $page->ID, '_booking_prop_id', true );

      $output .= '<div id="thanks-block">';

      //<h3>'.__('Thank you for your request, one of our staff will respond shortly.', VR_BOOKING_TEXTDOMAIN).'</h3>';

      $output .= __('Reservation number: ', VR_BOOKING_TEXTDOMAIN). $reserv_code . '<br><br>
      </div>';

      $output .= '<h2 id="title1">'.__('Your reservation details', VR_BOOKING_TEXTDOMAIN).'</h2>';

      $output .= $this->apt_info($post_id, $page->ID);

      $output .= '<div id="thanks">';

      $nights = date_diff(date_create(date( "Y-m-d", get_post_meta( $page->ID, '_booking_date_from', true ))), date_create(date( "Y-m-d", get_post_meta( $page->ID, '_booking_date_to', true ))))->days;

      $output .= '<table><tbody>
          <tr><td>'.__('First name: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.get_post_meta( $page->ID, '_booking_first_name', true ).'
          </td></tr>
          <tr><td>'.__('Last name: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.get_post_meta( $page->ID, '_booking_last_name', true ).'
          </td></tr>

          <tr><td>'.__('Arrival Date: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.date( "d/m/Y", get_post_meta( $page->ID, '_booking_date_from', true )).'
          </td></tr>
          <tr><td>'.__('Departure Date: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.date( "d/m/Y", get_post_meta( $page->ID, '_booking_date_to', true )).'
          </td></tr>
          <tr><td>'.__('Nights: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.$nights.'
          </td></tr>
          <tr><td>'.__('Guests: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.get_post_meta( $page->ID, '_booking_n_adults', true ).'
          </td></tr>
          <tr><td>'.__('Contacts: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.get_post_meta( $page->ID, '_booking_email', true ).'<br>'.get_post_meta( $page->ID, '_booking_phone', true ).'
          </td></tr>
          <tr><td>'.__('Price per night (avg.): ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.$this->format_currency(round(floatval(get_post_meta( $page->ID, '_booking_nights_price', true ))/floatval($nights), 2)).'
          </td></tr>
          <tr><td>'.__('TOTAL PRICE: ', VR_BOOKING_TEXTDOMAIN).'
          </td><td>'.$this->format_currency(get_post_meta( $page->ID, '_booking_price', true )).'
          </td></tr>
      </tbody></table>';

      $output .= '</div>';
      }
  }

  // print_r($_POST);
   return $output;
}

///////////////////
function property_page_shortcode(){
   $output = '';
$post_id = get_the_ID();

               $output .= '<div id="app-page">';

               /////////// Photos

               $output .= '<div id="tab_block"><span class="doc_tab cur_tab" data-x="app-photos">'.__('Photos', VR_BOOKING_TEXTDOMAIN).'</span><span class="doc_tab" data-x="app-desc">'.__('Description', VR_BOOKING_TEXTDOMAIN).'</span>
              </div>';

               $output .= '<div id="app-photos" class="doc_tab_div active">';
               $output .= get_the_post_thumbnail($post_id, 'full' );
               $output .= '</div>';

               ////////// Decription

               $output .= '<div id="app-desc" class="doc_tab_div">';

               $output .= apply_filters( 'the_content', get_the_content());

               $output .= '</div>';

               $output .= '</div>';

   return $output;
}

//////////// Services Page  //////////
//////////// Booking Page  ////////

function booking_page_shortcode(){

  $output = '';

  if (!empty($_POST['id']) && $this->validate_date($_POST['date_from']) && $this->validate_date($_POST['date_to'])){
    
  $post_id = intval($_POST['id']);  
    
  if (!empty($_POST['children'])) $children = intval($_POST['children']);
  else $children = 0;

  $price_arr = $this->get_all_rates_by_ap_id($post_id, $this->date_to_sql($_POST['date_from']), $this->date_to_sql($_POST['date_to']));

  $amount = round($price_arr['total'], 2)*100;

  $output .= $this->form_search_request2();

  $output .= '<h2 id="title1">'.__('Your booking', VR_BOOKING_TEXTDOMAIN).'</h2>';

   $output .= $this->apt_info($post_id);

  $output .= '<div id="booking-block">
  <span>'.__('Please review your information, then fill out the booking form. All fields marked with * must be filled in.', VR_BOOKING_TEXTDOMAIN).'</span>
  <form id="booking" name="booking" method="post">
  <h3>'.__('Guest', VR_BOOKING_TEXTDOMAIN).'</h3>

  <div>
  <label for="first_name">'.__('First Name*', VR_BOOKING_TEXTDOMAIN).'</label><br>
  <input id="first_name" name="first_name" type="text" value="">
  </div>

  <div>
  <label for="last_name">'.__('Last Name*', VR_BOOKING_TEXTDOMAIN).'</label><br>
  <input id="last_name" name="last_name" type="text" value="">
  </div>

  <h3>'.__('Contacts', VR_BOOKING_TEXTDOMAIN).'</h3>
  <div>
  <label for="email">'.__('Email*', VR_BOOKING_TEXTDOMAIN).'</label><br>
  <input id="email" name="email" type="text" value="">
  </div>

  <div>
  <label for="tel1">'.__('Phone/Mobile*', VR_BOOKING_TEXTDOMAIN).'</label><br>
  <input id="tel1" name="tel1" type="text" value="">
  </div>';

  $output .= '<div id="payment_methods">';

     $output .= '<input id="cash" name="payment_method" type="hidden" value="cash">';

     $output .= '<h3>'.__('Amount to pay later: ', VR_BOOKING_TEXTDOMAIN).$this->format_currency(round($price_arr['total'], 2)).'</h3>';
  $output .= '<input type="hidden" name="amount" value="full">';


  $output .= '<div>
  <input type="submit" class="bc-button-color" name="book" id="book" value="BOOK NOW">
  </div>
  <input type="hidden" name="date_from" value="'.$_POST['date_from'].'">
  <input type="hidden" name="date_to" value="'.$_POST['date_to'].'">
  <input type="hidden" name="adults" value="'.intval($_POST['adults']).'">
  <input type="hidden" name="children" value="'.$children.'">
  <input type="hidden" name="rooms" value="1">
  <input type="hidden" name="id" value="'.$post_id.'">';

  $output .= '</form>

  </div>';
  }

  return $output;
}

///////////////

function apt_info($post_id, $confirm_page = ''){
  $output = '';

  $output .='<div id="apt_short_info">
          '.get_the_post_thumbnail($post_id, 'post1-thumbnail' ).'
          <table><tbody>
          <tr><td colspan="2">'.get_the_title($post_id).'</td></tr>
          <tr><td>'.__('Address', VR_BOOKING_TEXTDOMAIN).'</td><td>'.get_post_meta( $post_id, '_property_address', true ).'</td></tr>
          <tr><td>'.__('Accommodates', VR_BOOKING_TEXTDOMAIN).'</td><td>'.get_post_meta( $post_id, '_property_max_guests', true ).'</td></tr>';

          $output .='
          </tbody></table>
          </div>';

  return $output;
}

/////////////////////////////

function form_search_request2(){
  $output = '';
  
  $price_arr = $this->get_all_rates_by_ap_id(intval($_POST['id']), $this->date_to_sql($_POST['date_from']), $this->date_to_sql($_POST['date_to']));
          
  $price_total = !empty($price_arr) ? $price_arr['total'] : '';

  $output .= '<div id="search-request">
    <div id="apartment_r"><label>'.__('Apartment: ', VR_BOOKING_TEXTDOMAIN).'</label><br><span>'.get_the_title($_POST['id']).'</span></div>
    <div id="date_from_r"><label>'.__('Arrival Date: ', VR_BOOKING_TEXTDOMAIN).'</label><br><span>'.$_POST['date_from'].'</span></div>
    <div id="date_to_r"><label>'.__('Departure Date: ', VR_BOOKING_TEXTDOMAIN).'</label><br><span>'.$_POST['date_to'].'</span></div>
    <div id="adults_r"><label>'.__('Guests: ', VR_BOOKING_TEXTDOMAIN).'</label><br><span>'.$_POST['adults'].'</span></div>
    <div id="location_r"><label><strong>'.__('Total Price: ', VR_BOOKING_TEXTDOMAIN).'</strong></label><br><span>'.$this->format_currency($price_total).'</span></div>
  </div>
  ';

  return $output;
}

///////// Search Result Page  //////////////

function search_page_shortcode($atts){
  $output = '';

  if ((empty($_POST['adults']) || empty($_POST['date_from']) || empty($_POST['date_to']) || !$this->validate_date($_POST['date_from']) || !$this->validate_date($_POST['date_to']))or(strtotime($this->date_to_sql($_POST['date_from']) . ' 00:00:00') >= strtotime($this->date_to_sql($_POST['date_to']) . ' 00:00:00'))){return $output;}

  $output .= $this->form_search_request();

/*  $args = shortcode_atts( array(
        'title' => __('Our Apartments', VR_BOOKING_TEXTDOMAIN)
	), $atts, 'booking-home' );

  $output .= '<h2 id="title1" class="center-title">'.$args['title'].'</h2>';
*/
  
  $rooms = 1;

  $arr = $this->get_free_appartments_front($_POST['date_from'], $_POST['date_to'], intval($_POST['adults']), intval($rooms));

       if(!empty($arr)){

  $output .= '<div id="result-row-block">'.$arr['output'].'</div>';

  if(!empty($arr['pages'])){
  $page_line = '';
  for($i=1; $i<=$arr['pages']; $i++){
     if($i == $arr['page_num']) $class = ' cur_page';
     else $class = '';
     $page_line .= '<span class="pager_num'.$class.'" data-x="'.$i.'">'.$i.'</span>';
  }
  $output .= '<div id="pager">'.$page_line.'</div>';
     }
    }

  return $output;
}

///////////////////////////////

function form_search_request(){
  $output = '';
  
  $rooms = 1;

  $output .= '<div id="search-request">
    <div id="date_from_r"><label>'.__('Arrival Date: ', VR_BOOKING_TEXTDOMAIN).'</label><br><span>'.$_POST['date_from'].'</span></div>
    <div id="date_to_r"><label>'.__('Departure Date: ', VR_BOOKING_TEXTDOMAIN).'</label><br><span>'.$_POST['date_to'].'</span></div>
    <div id="adults_r"><label>'.__('Guests: ', VR_BOOKING_TEXTDOMAIN).'</label><br><span>'.$_POST['adults'].'</span></div>
    </div>
  ';

  return $output;
}

///////////// get quote by apartment id

function form_get_quote_by_ap_id($ap_id){

  $date_from = '';
  $date_to = '';

  $form_action = '/booking';

  $output = '<form id="get_quote_ap" name="get_quote_ap" method="post" action="'.$this->home_url.$form_action.'">

  <input id="date_from" type="text" name="date_from" value="" placeholder="'.__('Arrival Date', VR_BOOKING_TEXTDOMAIN).'">
  <input id="date_to" type="text" name="date_to" value="" placeholder="'.__('Departure Date', VR_BOOKING_TEXTDOMAIN).'">

  <label for="adults">'.__('Guests:', VR_BOOKING_TEXTDOMAIN).'</label>
  <select id="adults" name="adults" size="1">';
  for ($i=1; $i<=get_post_meta( $ap_id, '_property_max_guests', true ); $i++){
  $output .= '<option value="'.$i.'"';
  if ($i == 1) $output .= ' selected';
  $output .= '>'.$i.'</option>';
  }
  $output .= '</select>

  <input id="continue" type="button" class="bc-button-color" name="continue" value="'.__('CONTINUE', VR_BOOKING_TEXTDOMAIN).'">

          <input type="hidden" name="rooms" value="'.get_post_meta( $ap_id, '_property_n_rooms', true ).'">
          <input type="hidden" name="id" value="'.$ap_id.'">

  </form>';

  return $output;
}

//////////////

function form_get_quote(){

  $date_from = !empty($_POST['date_from']) && $this->validate_date($_POST['date_from']) ? $_POST['date_from'] : '';
  $date_to = !empty($_POST['date_to']) && $this->validate_date($_POST['date_to']) ? $_POST['date_to'] : '';

  $output = '<form id="get_quote" name="get_quote" method="post" action="'.$this->home_url.'/search-result">

  <div>
  <input id="date_from" type="text" name="date_from" value="'.$date_from.'" placeholder="'.__('Arrival Date', VR_BOOKING_TEXTDOMAIN).'">
  </div>
  <div>
  <input id="date_to" type="text" name="date_to" value="'.$date_to.'" placeholder="'.__('Departure Date', VR_BOOKING_TEXTDOMAIN).'">
  </div>

  <div>
  <select id="adults" name="adults" size="1">';
  if (empty($_POST['adults'])) $output .= '<option name="start" disabled selected>'.__('Guests', VR_BOOKING_TEXTDOMAIN).'</option>';
  else
  $output .= '<option name="start" disabled>'.__('Guests', VR_BOOKING_TEXTDOMAIN).'</option>';
  for ($i=1; $i<=$this->settings['max_select_adults']; $i++){
  $output .= '<option value="'.$i.'"';
  if ((!empty($_POST['adults']))and($i == $_POST['adults'])) $output .= ' selected';
  $output .= '>'.$i.'</option>';
  }
  $output .= '</select>
  </div>

  <div>
  <input id="guote" type="submit" class="bc-button-color" name="guote" value="'.__('SEARCH', VR_BOOKING_TEXTDOMAIN).'">
  </div>
  </form>';

  return $output;
}

///////////// Home page ////////////////

function home_page_shortcode($atts){
  $output = '';

  $args = shortcode_atts( array(
        'title' => __('Our Apartments', VR_BOOKING_TEXTDOMAIN),
        'search' => "true"
	), $atts, 'booking-home' );
  
  $args['search'] = ($args['search'] == "false") ? false : true;

  $arr = $this->get_all_appartments_front();

  if(!empty($arr)){
    
  $output .= '<h2 class="center-title">'.$args['title'].'</h2>
  ';
  
  if ($args['search']){
    $output .= $this->form_get_quote();
  }

  $output .= '<div id="home_results">'.$arr['post_blocks'].'</div>';
  $page_line = '';
  for($i=1; $i<=$arr['pages']; $i++){
     if($i == $arr['page_num']) $class = ' cur_page';
     else $class = '';
     $page_line .= '<a href="?page_num='.$i.'"><span class="pager_num'.$class.'" data-x="'.$i.'">'.$i.'</span></a>';
  }
  $output .= '<div id="pager">'.$page_line.'</div>';
  }

  return $output;
}

/////////////

function date_to_sql($date){
  if ($date){
  $date_arr = explode('/', $date);
  if (sizeof($date_arr) == 3)
  return $date_arr[2].'-'.$date_arr[1].'-'.$date_arr[0];
  }
  else return '';
}

function date_from_sql($date){

  if ($date!=="0000-00-00"){
  $date_arr = explode('-', $date);
  if (sizeof($date_arr) == 3)
  return $date_arr[2].'/'.$date_arr[1].'/'.$date_arr[0];
  }
  else return '';
}

////////////////////////////

function get_all_appartments_front(){
   $output = '';
   $res_arr = array();

    $args = array(
               'post_type' => 'property',
               'posts_per_page'=> -1,
                  );

    $the_query = new WP_Query( $args );
      $i = 1;
     while ( $the_query->have_posts() ) : $the_query->the_post();

          $post_id = get_the_ID();

          $price = $this->get_price_min($post_id);

          if ($price) {

          $res_arr[$i]['price'] = $price;
          $res_arr[$i]['res'] ='<div class="result-block">
          <a href="'.get_permalink($post_id).'"><h4>'.get_the_title($post_id).'</h4></a>
          '.get_the_post_thumbnail($post_id, 'post1-thumbnail' ).'
          <div class="from_price">'.__('from', VR_BOOKING_TEXTDOMAIN).' <span class="from_price_amount">'.$this->format_currency($price).'</span>'.__(' per night', VR_BOOKING_TEXTDOMAIN).'</div>
          <a href="'.get_permalink($post_id).'"><input type="button" class="bc-button-color" value="'.__('View Listing', VR_BOOKING_TEXTDOMAIN).'" name="view" id="view-'.$post_id.'"></a>
          </div>';
            $i++;
            }
     endwhile;
/* Restore original Post Data */
wp_reset_postdata();

   if (!empty($res_arr)){
      $tmp = Array();
      foreach($res_arr as &$ma) $tmp[] = &$ma["price"];

      $sort_order = SORT_ASC;

      array_multisort($tmp, $sort_order, $res_arr);
      //array_splice ($res_arr, 10);  // sort and save top 10 matches
      if (get_query_var('page_num')){
        $page_num = get_query_var('page_num');
        $offset = (get_query_var('page_num')-1)*$this->settings['search_res_front'];
        }
        else {
        $page_num = 1;
        $offset=0;
        }
        array_splice ($res_arr, 0, $offset);
        array_splice ($res_arr, $this->settings['search_res_front']);
        foreach($res_arr as $res_arr_item) $output .= $res_arr_item['res'];
   }

   if ($output) {
      $arr['post_blocks'] = $output;
      $arr['total_rec'] = $i-1;
      $arr['pages'] = intval(ceil(($i-1)/$this->settings['search_res_front']));
      $arr['page_num'] = $page_num;
      return $arr;
  }

   return array();
}

///////////////////////////////////
///// check free apartment by id

function is_free_appartment($from_date, $to_date, $ap_id){
   $output = true;

   $to = strtotime($this->date_to_sql($to_date));
   $from = strtotime($this->date_to_sql($from_date));

   wp_reset_postdata();

   $args = array(
               'post_type' => 'booking',
               'posts_per_page'=> -1,
               'meta_query' => array(
                  array(
                    'key'     => '_booking_prop_id',
                    'value'   => $ap_id,
                    'compare' => '=',
                    'type'    => 'NUMERIC',
                    ),
                    ),
                   );

    $the_query = new WP_Query( $args );
     while ( $the_query->have_posts() ) : $the_query->the_post();
          $booking_id = get_the_ID();
          $booking_date_from = get_post_meta( $booking_id, '_booking_date_from', true );
          $booking_date_to = get_post_meta( $booking_id, '_booking_date_to', true );
          if ((($booking_date_from < $to)&&(($booking_date_to >= $to)))||(($booking_date_from <= $from)&&(($booking_date_to > $from)))){
          $output = false;
          break;
          }
     endwhile;
wp_reset_postdata();

   return $output;
}

///////////////////

function get_free_appartments_front($from_date, $to_date, $guests, $rooms){
   $output = '';

   $args = array(
               'post_type' => 'booking',
               'posts_per_page'=> -1,
               'meta_query' => array(
                  'relation' => 'OR',
                  array(
                  'relation' => 'AND',
                  'date_from' => array(
                    'key'     => '_booking_date_from',
                    'value'   => strtotime($this->date_to_sql($to_date)),
                    'compare' => '<',
                    'type'    => 'NUMERIC',
                    ),
                  'date_to' => array(
                    'key'     => '_booking_date_to',
                    'value'   => strtotime($this->date_to_sql($to_date)),
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                    ),
                   ),
                  array(
                  'relation' => 'AND',
                  'date_from2' => array(
                    'key'     => '_booking_date_from',
                    'value'   => strtotime($this->date_to_sql($from_date)),
                    'compare' => '<=',
                    'type'    => 'NUMERIC',
                    ),
                  'date_to2' => array(
                    'key'     => '_booking_date_to',
                    'value'   => strtotime($this->date_to_sql($from_date)),
                    'compare' => '>',
                    'type'    => 'NUMERIC',
                    ),
                    ),
                   ),
                  );
    $id_exclude = array();
    $the_query = new WP_Query( $args );

     while ( $the_query->have_posts() ) : $the_query->the_post();

          $id_exclude[] = get_post_meta( get_the_ID(), '_booking_prop_id', true );

     endwhile;
/* Restore original Post Data */
wp_reset_postdata();

      // print_r($id_exclude);
    $args = array(
               'post_type' => 'property',
               'post__not_in' => $id_exclude,
               'posts_per_page'=> -1,
               'meta_query' => array(
                  'relation' => 'AND',
                  'n_rooms' => array(
                    'key'     => '_property_n_rooms',
                    'value'    => $rooms,
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                    ),
                  'max_guests' => array(
                    'key'     => '_property_max_guests',
                    'value'   => $guests,
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                    ),
                  ),
                  );

     $res_arr = array();

    $the_query = new WP_Query( $args );
       $i=1;

     while ( $the_query->have_posts() ) : $the_query->the_post();
          $post_id = get_the_ID();

          $form_action = '/booking';

          $price_arr = $this->get_all_rates_by_ap_id($post_id, $this->date_to_sql($from_date), $this->date_to_sql($to_date));
          $price_total = '';
          $price = '';

          if (!empty($price_arr)){
            $price_total = $price_arr['total'];
            $price = $price_arr['min'];
          }

          if ($price) {

          $res_arr[$i]['price'] = $price;
          $res_arr[$i]['res'] = '<div class="result-row">
          <div class="app-details">
          <a href="'.get_permalink($post_id).'"><h4>'.get_the_title($post_id).'</h4></a>
          <table><tbody>
          <tr><td>'.__('Accommodates', VR_BOOKING_TEXTDOMAIN).'</td><td>'.get_post_meta( $post_id, '_property_max_guests', true ).'</td></tr>
          </tbody></table>
          </div>
          <div class="app-img">'.get_the_post_thumbnail($post_id, 'post1-thumbnail' ).'</div>
          <div class="app-price">
          <span class="total">'.__('Total: ', VR_BOOKING_TEXTDOMAIN).$this->format_currency($price_total).'
          </span>';

          $res_arr[$i]['res'] .= '</div>
          <div class="app-reserv">
          <form id="booking_'.$post_id.'" name="booking_'.$post_id.'" action="'.$this->home_url.$form_action.'" method="post">
          <input type="hidden" name="date_from" value="'.$_POST['date_from'].'">
          <input type="hidden" name="date_to" value="'.$_POST['date_to'].'">
          <input type="hidden" name="adults" value="'.$_POST['adults'].'">
          <input type="hidden" name="rooms" value="1">
          <input type="hidden" name="id" value="'.$post_id.'">
          <input type="submit" class="bc-button-color" value="'.__('BOOK NOW', VR_BOOKING_TEXTDOMAIN).'" name="reserve" id="reserve">
          </form>
          </div>
          </div>';
            $i++;
            }
 
     endwhile;
/* Restore original Post Data */
wp_reset_postdata();

   if (!empty($res_arr)){
      $tmp = Array();
      
      foreach($res_arr as &$ma) $tmp[] = &$ma["price"];

      $sort_order = SORT_ASC;

      array_multisort($tmp, $sort_order, $res_arr);
      //array_splice ($res_arr, 10);  // sort and save top 10 matches
      if (get_query_var('page_num')){
        $page_num = get_query_var('page_num');
        $offset = (get_query_var('page_num')-1)*$this->settings['search_res_other'];
        }
        else {
        $page_num = 1;
        $offset=0;
        }
        array_splice ($res_arr, 0, $offset);
        array_splice ($res_arr, $this->settings['search_res_other']);
        foreach($res_arr as $res_arr_item) $output .= $res_arr_item['res'];
   }
    if ($output){
      $arr['output'] = $output;
      $arr['total_rec'] = $i-1;
      $arr['pages'] = intval(ceil(($i-1)/$this->settings['search_res_other']));
      $arr['page_num'] = $page_num;
   }
  else {
      $arr['output'] = '<div id="sorry_search">'.__('Sorry, we do not have available appartments for these dates. Please try another dates.', VR_BOOKING_TEXTDOMAIN).'</div>';
      $arr['markers']='';
   }
   return $arr;
}

//////////////////////////////

public function get_price_min($post_id){

   $res = $this->get_all_rates_by_ap_id($post_id, date("Y-m-d"), date("Y-m-d", time() + 365*24*60*60));

   return $res['min'];
}

///////////// End of Class

}

Global $VRBooking_var;

$VRBooking_var = new VRBooking();


